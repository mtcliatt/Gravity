/**
 * Creates an instance of GPointerLockControls
 * @constructor
 * @param {object} camera the camera of the scene
 * @param {object} gravity the gravity currently in effect
 * @param {number} speed the speed at which the camera will move 
 *                       (not currently used)
 */
function GPointerLockControls (camera, gravity, speed) {
	var self = this;
  
	camera.rotation.set( 0, 0, 0 );

	self.pitchObject = new THREE.Object3D();
	self.pitchObject.add(camera);
	self.yawObject = new THREE.Object3D();
    
	self.yawObject.add(self.pitchObject);
  
  self.gListeners = [];
  self.dListeners = [];
  
  self.canShift = true;
  self.setGravity(gravity);
  
  self.velocity = new THREE.Vector3();
  
  self.direction = new THREE.Vector3(0, 0, -1);
	self.rotation = new THREE.Euler(0, 0, 0, "YXZ");
  
  self.forward = false;
  self.backward = false;
  self.left = false;
  self.right = false;
  
	document.addEventListener('mousemove', self._onMouseMove.bind(self), false);
  document.addEventListener('keydown', self._onKeyDown.bind(self), false);
  document.addEventListener('keyup', self._onKeyUp.bind(self), false);

	self.enabled = false;
}

/**
 * Updates the control object
 * #update
 * @param {number} delta the time difference between calls 
 *                       (may be moved internally)
 * @param {array} objects the objects that may be collided with
 */
GPointerLockControls.prototype.update = function(delta, objects) {
  var self = this;
  
  if(!self.enabled) {
    return;
  }
  
  self._updateVelocity(delta);
  self._updateGravity(delta, objects);
  
  // translate camera
  self.yawObject.translateX(self.velocity.x * delta);
  self.yawObject.translateZ(self.velocity.z * delta);
  self.yawObject.translateY(self.velocity.y * delta);
};

/**
 * Update the velocity of the camera
 * #_updateVelocity
 * @param {number} delta the time since last call
 */
GPointerLockControls.prototype._updateVelocity = function(delta) {
  var self = this;
  
  if(!self.forward && !self.backward) {
    self.velocity.z = 0;
  }
  
  if(!self.left && !self.right) {
    self.velocity.x = 0;
  }
  
  if(self.forward) {
    self.velocity.z = Math.max(-75, self.velocity.z - (400 * delta));
  }
  
  if(self.backward) {
    self.velocity.z = Math.min(75, self.velocity.z + (400 * delta));
  }
  
  if(self.left) {
    self.velocity.x = Math.max(-75, self.velocity.x - (400 * delta));
  }
  
  if(self.right) {
    self.velocity.x = Math.min(75, self.velocity.x + (400 * delta));
  }
};

/**
 * Update the effect of gravity on the camera
 * #_updateGravity
 * @param {number} delta the time since last call
 * @param {array} objects the objects that the camera may run into
 */
GPointerLockControls.prototype._updateGravity = function(delta, objects) {
  var self = this;
  
  self.velocity.y -= 9.8 * 100 * delta;
  
  self.raycaster.ray.origin.copy(self.yawObject.position);
  self.raycaster.ray.origin[self.gravity.gravity.axis] +=
    self.gravity.gravity.mult * 10;
  
  self.raycaster.far = Math.abs(self.velocity.y * delta);
  
  var intersects = self.raycaster.intersectObjects(objects);
  if(intersects.length) {
    var distance = intersects[0].distance;
    self.yawObject.translateY(-distance);
    
    self.velocity.y = 0;
    self.canShift = true;
    self.emitGravityEvent();
  }
};

/**
 * Returns the object3d of the controls
 * #getObject
 * @returns {object}
 */
GPointerLockControls.prototype.getObject = function() {
  var self = this;
  
  return self.yawObject;
};

/**
 * Returns the directional facing of the controls
 * #getDirection
 * @param {object} v the vector the become the direction vector
 * @returns {object}
 */
GPointerLockControls.prototype.getDirection = function(v) {
  var self = this;
  
  self.rotation.set(self.pitchObject.rotation.x, 
                    self.yawObject.rotation[self.gravity.gravity.axis], 0);
	v.copy(self.direction).applyEuler(self.rotation);

	return v;
};

/**
 * Disposes the controls by cleaning up listeners
 * #dispose
 */
GPointerLockControls.prototype.dispose = function() {
  var self = this;
  
  document.removeEventListener('mousemove', self._onMouseMove.bind(self), false);
  document.removeEventListener('keydown', self._onKeyDown.bind(self), false);
  document.removeEventListener('keyup', self._onKeyUp.bind(self), false);
};

/**
 * Sets the gravity of the controls (used internally)
 * #setGravity
 * @param {object} gravity
 */
GPointerLockControls.prototype.setGravity = function(gravity) {
  var self = this;
  
  if(self.canShift) {
    var yaw = 0;
    if(self.gravity) {
      yaw = self.yawObject.rotation[self.gravity.gravity.axis];
    }
    
    self.gravity = gravity;
    
    self.yawObject.rotation.set(0, 0, 0);
    self.pitchObject.rotation.set(0, 0, 0);
    
    self.yawObject.rotation.z = 
      self.gravity.rotation;
    
    self.yawObject.rotation[self.gravity.gravity.axis] = yaw;
      
    var vec = new THREE.Vector3(0, 0, 0);
    vec[self.gravity.gravity.axis] = self.gravity.gravity.mult;
    self.raycaster = new THREE.Raycaster(new THREE.Vector3(0, 0, 0), vec);
  }
  
  self.canShift = false;
  self.emitGravityEvent();
};

/**
 * Registers a new listener to receive gravity updates
 * #addGravityListener
 * @param {function} listener
 */
GPointerLockControls.prototype.addGravityListener = function(listener) {
  var self = this;
  
  self.gListeners.push(listener);
};

/**
 * Emits a gravity event to all registered listeners
 * #emitGravityEvent
 */
GPointerLockControls.prototype.emitGravityEvent = function() {
  var self = this;
  
  var event = {
    gravity: self.gravity,
    active: !self.canShift
  };
  
  self.gListeners.forEach(function(listener) {
    listener(event);
  });
};

/**
 * Registers a new listener to receive direction updates
 * #addDirectionListener
 * @param {function} listener
 */
GPointerLockControls.prototype.addDirectionListener = function(listener) {
  var self = this;
  
  self.dListeners.push(listener);
};

/**
 * Emits a gravity event to all registered listeners
 * #emitGravityEvent
 */
GPointerLockControls.prototype.emitDirectionEvent = function() {
  var self = this;
  
  var event = {
    direction: self.getDirection(new THREE.Vector3())
  };
  
  self.dListeners.forEach(function(listener) {
    listener(event);
  });
};

/**
 * Defines the mouse move functionality of the controls
 * #_onMouseMove
 * @param {object} event
 */
GPointerLockControls.prototype._onMouseMove = function(event) {
  var self = this;
  
  if (!self.enabled) {
    return;
  }

	var movementX = event.movementX || event.mozMovementX || event.webkitMovementX || 0;
	var movementY = event.movementY || event.mozMovementY || event.webkitMovementY || 0;
  var PI_2 = Math.PI / 2;

	self.yawObject.rotation[self.gravity.gravity.axis] += 
    self.gravity.stride.left *  movementX * 0.002;
	self.pitchObject.rotation.x -= movementY * 0.002;

	self.pitchObject.rotation.x =
    Math.max(-PI_2, Math.min(PI_2, self.pitchObject.rotation.x));
  
  self.emitDirectionEvent();
};

/**
 * Defines the key down functionality of the controls
 * #_onKeyDown
 * @param {object} event
 */
GPointerLockControls.prototype._onKeyDown = function(event) {
  var self = this;
  
  switch(event.keyCode) {
    case 87: // w
			self.forward = true;
			break;
		case 65: // a
			self.left = true;
      break;
		case 83: // s
			self.backward = true;
			break;
		case 68: // d
			self.right = true;
			break;
    case 37: //left
      self.setGravity(Gravity.LEFT);
      break;
    case 38: // up
      self.setGravity(Gravity.UP);
      break;
    case 39: // right
      self.setGravity(Gravity.RIGHT);
      break;
    case 40: // down
      self.setGravity(Gravity.DOWN);
      break;
  }
};

/**
 * Defines the key up functionality of the controls
 * #_onKeyUp
 * @param {object} event
 */
GPointerLockControls.prototype._onKeyUp = function(event) {
  var self = this;
  
  switch(event.keyCode) {
    case 87: // w
			self.forward = false;
			break;
		case 65: // a
			self.left = false; 
      break;
		case 83: // s
			self.backward = false;
			break;
		case 68: // d
			self.right = false;
			break;
  }
};
